# Course Release Manager

Version 1.0.0. Private, downloadable skills plugin with local helper scripts.

## Use
Import this individual ZIP with a compatible plugin host's plugin import/install workflow, when available. Then select the plugin in a chat, provide the files or folder you want to work on, and use one of the suggested prompts in its manifest. This download does not install itself or save a plugin to your account.

If your host does not accept plugin ZIPs, keep the extracted folder and use the SKILL.md workflows with an assistant that can read local files. Compatibility/import has not been tested in your account. Do not paste a local download path into a remote-server connection field.

## Included workflows
- audit-course-release
- package-course-release

## Runtime and persistence
The guided workflows can operate on supplied text. Local helper scripts require Python 3.10+ and use only its standard library. Resolve their path inside skills/ and run --help for exact arguments. Templates are relative to the skill that references them. Store catalogs, drafts, queues and reports in a user-selected workspace, never in this installed plugin folder. Local paths are examples, not existing resources.

This package contains no MCP server, hosted app, scheduled process, external credentials or mandatory third-party plugin dependencies. It does not automatically discover all chats, sync accounts, publish content, edit video, or deploy websites. The host supplies model access and any file/browser capabilities. No persistence is claimed unless a file or connected document was actually saved.

## Privacy and portability
The bundled scripts read selected local inputs and write local state; they make no network requests. When used through an AI host, that host and any separately used connectors govern transmission and storage of material provided to them. Review inputs for material you are permitted to use. Back up your JSON state and documents; they are not tied to an online service.

## Verification
See VALIDATION.md for the checks actually performed. Package validation and local script checks do not prove host import, account installation or model behavior.
