# Course release report
Course, version, date and source revision: <value>
Decision: <ready / ready with limitations / incomplete>
Intended audience and deliverables: <value>

## Requirements coverage
<Matrix location; missing or partial core requirements.>

## Teaching review
<Lessons actually reviewed, criteria, findings and remaining sampling gaps.>

## Verification
| Check | Method/command | Observed result | Evidence | Limits |
|---|---|---|---|---|

## Unperformed checks and known limitations
<Credentialed services, native builds, browser checks, factual review or other actual gaps.>

## Package handoff
<ZIP name, checksum/report location, inventory review, start instructions.>

## Changelog
<Concrete changes and compatibility effects.>
