"""Audit course files and create a checked portable ZIP. Python 3.10+."""
import argparse, hashlib, json, pathlib, re, zipfile
from urllib.parse import unquote, urlsplit

SKIP = {'.git', '.venv', 'node_modules', '__pycache__', '.env', '.openai'}
SECRET_NAMES = {'.env', '.npmrc', '.pypirc', 'credentials', 'id_rsa', 'id_ed25519'}
SECRET_EXTENSIONS = {'.pem', '.key', '.p12', '.pfx'}

def audit(root):
    files = []; errors = []; warnings = []; inventory = []
    for path in sorted(root.rglob('*')):
        rel = path.relative_to(root)
        if any(p in SKIP for p in rel.parts[:-1]): continue
        if path.is_symlink(): errors.append(f'Symlink excluded: {rel.as_posix()}'); continue
        if not path.is_file(): continue
        if path.name in SECRET_NAMES or path.name.startswith('.env.') or path.suffix.lower() in SECRET_EXTENSIONS:
            errors.append(f'Potential credential file excluded: {rel.as_posix()}'); continue
        if any(p in SKIP for p in rel.parts): continue
        files.append(path)
        inventory.append({'path': rel.as_posix(), 'bytes': path.stat().st_size,
                          'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
        if path.suffix.lower() not in {'.md', '.mdx'}: continue
        body = path.read_text(encoding='utf-8-sig')
        fence = None; prose = []
        for line in body.splitlines():
            match = re.match(r'^\s{0,3}(`{3,}|~{3,})(.*)$', line)
            if match:
                marks, rest = match.groups()
                if fence is None: fence = marks
                elif marks[0] == fence[0] and len(marks) >= len(fence) and not rest.strip(): fence = None
                continue
            if fence is None: prose.append(line)
        if fence: errors.append(f'Unclosed code fence: {rel.as_posix()}')
        clean = '\n'.join(prose)
        if re.search(r'\b(TODO|TBD|FIXME)\b|\[INSERT[^\]]*\]', clean): warnings.append(f'Placeholder marker: {rel.as_posix()}')
        for target in re.findall(r'!?\[[^\]]*\]\(\s*(<[^>]+>|[^\s)]+)', clean):
            target = target.strip('<>')
            parsed = urlsplit(target)
            if parsed.scheme or parsed.netloc or not parsed.path: continue
            if target.startswith('/'):
                warnings.append(f'Site-root link needs route check: {rel.as_posix()} -> {target}'); continue
            dest = (path.parent / unquote(parsed.path)).resolve()
            if not dest.is_relative_to(root): errors.append(f'Link leaves course root: {rel.as_posix()} -> {target}')
            elif not dest.exists(): errors.append(f'Missing local target: {rel.as_posix()} -> {target}')
    if not files: errors.append('No packageable files')
    return files, {'schema_version': 1, 'root': str(root), 'errors': errors, 'warnings': warnings, 'inventory': inventory,
                   'limitations': ['No teaching-quality or factual review', 'No external URL or anchor checks',
                                   'No HTML/MDX route resolution or browser check', 'No execution of course examples',
                                   'Credential filename checks are not a comprehensive secret scan']}

def main():
    p = argparse.ArgumentParser(description=__doc__); p.add_argument('root', type=pathlib.Path)
    p.add_argument('--report', type=pathlib.Path, required=True); p.add_argument('--zip', type=pathlib.Path)
    a = p.parse_args(); root = a.root.resolve(strict=True)
    if not root.is_dir(): p.error('Course root must be a directory')
    report = a.report.resolve(); target = a.zip.resolve() if a.zip else None
    if report.is_relative_to(root) or (target and target.is_relative_to(root)): p.error('Report and ZIP must be outside the course root')
    if target and target == report: p.error('Report and ZIP must use different paths')
    if report.exists() or (target and target.exists()): p.error('Output exists; use fresh versioned output filenames')
    files, result = audit(root)
    if target and not result['errors']:
        target.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
            for file in files: archive.write(file, (pathlib.Path(root.name)/file.relative_to(root)).as_posix())
        with zipfile.ZipFile(target) as archive:
            if archive.testzip(): raise RuntimeError('ZIP CRC verification failed')
            for entry in result['inventory']:
                name = root.name+'/'+entry['path']
                if hashlib.sha256(archive.read(name)).hexdigest() != entry['sha256']: raise RuntimeError('Archive hash mismatch')
        result['archive'] = str(target)
        result['archive_sha256'] = hashlib.sha256(target.read_bytes()).hexdigest()
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'files': len(files), 'errors': len(result['errors']), 'warnings': len(result['warnings']), 'report': str(report), 'archive': result.get('archive')}))
    return 1 if result['errors'] else 0

if __name__ == '__main__': raise SystemExit(main())
