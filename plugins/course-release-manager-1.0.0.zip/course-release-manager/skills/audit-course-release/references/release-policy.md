# Release policy
A release decision depends on learning requirements and evidence, not file volume. Do not mark unsupported integrations as verified. Keep exact source versions, commands, result summaries, and dates where applicable.

## Gates
- Content: each core outcome has a lesson, worked example, independent exercise and a usable feedback mechanism.
- Sources: changing technical claims have dated primary-source review; citations are traceable.
- Structure: no missing required files, broken checked local links, or unclosed code fences.
- Execution: representative examples and capstone flows are tested where feasible; unperformed live/credentialed checks are explicit.
- Website: build and actual navigation/interaction checks are distinct; browser verification is required before claiming visual checks passed.
- Portability: README, environment requirements, dependency versions, launcher instructions and known limitations are included.
- Archive: output outside source, stable version name, inspected inventory, successful integrity and content-hash checks.

## Bundled auditor
Python 3.10+, standard library only. Resolves simple inline Markdown local links outside fenced code; ignores external URLs and anchors. Site-root routes generate warnings. Reference-style links, HTML/MDX imports, rendered routes and URL availability need separate checks. It flags TODO/TBD/FIXME markers as warnings. Filename-based credential screening is incomplete; review contents separately. It makes no network calls and does not run course code.

```text
python scripts/release_check.py /user/course --report /user/releases/course-v1-audit.json
python scripts/release_check.py /user/course --report /user/releases/course-v1.0.0-report.json --zip /user/releases/course-v1.0.0.zip
```
Exit 0 means no detected structural errors; exit 1 means detected errors; invalid arguments or unexpected runtime failures also produce nonzero exit codes. Warnings need judgment. All output files must be new paths outside the course root. The ZIP contains one enclosing directory named after the course root. This is a course packager, not a plugin packager.
