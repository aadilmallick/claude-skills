---
name: audit-course-release
description: "Use to audit a course, textbook, companion site or curriculum package against its requirements, learning outcomes, exercise coverage and verification evidence."
---

# Audit a course release
Read `references/release-policy.md` and use the requirements and release-report templates. Work from the actual selected source tree, not only an earlier chat's completion summary.

1. Capture the target audience, prerequisite knowledge, learning outcomes, requested formats, source folder and release destination. Reuse explicit requirements. Distinguish planned effort from validated learning time. Do not treat word count or a nominal 1,000-hour label as proof of depth.
2. Inventory existing lessons, source references, exercises, answer keys, runnable examples, website pages and downloads. Map each promise to a concrete artifact in `templates/requirements-matrix.csv`. Mark missing, partial, verified, or unverified; include the evidence location.
3. Review teaching quality separately from structural checks: prerequisite order, first-principles explanations, meaningful worked examples, independent practice, feedback/rubrics, misconceptions, accessibility, and capstone alignment. Sample explicitly and report the sample scope; don't imply every lesson was reviewed if it wasn't.
4. Check factual currency where the content depends on changing APIs, SDK versions or policies. Use primary sources and record review dates and versions. Avoid inventing research or presenting a broken integration as working.
5. Run `scripts/release_check.py <course-root> --report <outside-root/report-v1.json>` when local execution is available. Inspect its errors, warnings and limitations. It checks simple Markdown links/fences and file hashes; it does not validate rendered routes, pedagogy or code correctness.
6. For a companion site, identify the actual stack and its documented build/check commands. Run appropriate existing checks. Verify search, navigation, mobile layout, quizzes, progress persistence and relevant download links in a real browser when available. Record blocked or unperformed checks. No need to install unrelated frameworks.
7. Resolve authorized fixes or create a prioritized gap list. Keep correctness and missing core content ahead of cosmetic issues. Use existing Curriculum Foundry/Textbook Workshop capabilities if actually installed; they are optional and are not bundled dependencies. Without them, edit the source directly as supported.
8. Return a release recommendation grounded in evidence: ready, ready with stated limitations, or incomplete. Use `templates/release-report.md`. Separate automated results, human/agent review, self-report, and unperformed checks.

Keep change logs and reports outside the installed plugin. Preserve user edits, source provenance and previous releases. Never run imported course scripts blindly; inspect commands and use the execution controls of the current host.
