---
name: package-course-release
description: "Use to assemble a versioned course ZIP, verify its contents, record release limitations, and hand off a portable course package."
---

# Package a course release
Read `../audit-course-release/references/release-policy.md`. Start with the requirements matrix and latest audit. A packaging pass is not proof that all course requirements are met.

1. Resolve the course root, intended contents, version and output directory. Use an explicit user version or choose an unused initial `1.0.0` and state that assumption. Never overwrite a release. Use a clean staging folder if the source contains unrelated materials.
2. Ensure a learner-facing README explains prerequisites, starting lesson, file layout, website setup if relevant, exercise/answer-key locations, and known limitations. Record versions and required credentials by name only. Ensure offline claims match actual behavior.
3. Review package contents for credentials, private source material and unnecessary dependencies. Exclude caches, build credentials and unrelated files. Keep required compiled website assets if the promised deliverable is a runnable static website. Filename checks in the bundled script are only one part of the review.
4. Copy the completed release report and changelog into the course staging folder if they are learner-facing. Keep the generated hash/inventory report outside the root to avoid self-reference. Resolve broken local links before packaging; explicitly review warnings.
5. Run `../audit-course-release/scripts/release_check.py <root> --report <outside-root/course-v1.0.0-report.json> --zip <outside-root/course-v1.0.0.zip>`. The script refuses to overwrite outputs or create a ZIP when structural errors exist, then checks CRCs and per-file hashes.
6. Inspect the actual ZIP inventory, hashes, unexpected files and required deliverables. If edits are made afterward, use fresh output filenames, rebuild and recheck. Open representative learner files and verify a local launcher or installation instructions if included.
7. Deliver the course ZIP and report with concise notes on what passed and outstanding gaps. If only a partial release is requested, label it explicitly. Preserve source and previous artifacts.

Creating a downloadable release does not authorize posting, sending, scheduling, publishing or altering site access. A site release should use the available hosting tools only when within the user's requested scope. Do not claim a site is live based on a local build. If a runtime or browser is unavailable, deliver the package and clearly identify that verification gap.
