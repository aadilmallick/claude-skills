# Validation

Version 1.0.0 was checked locally before packaging.

- JSON manifests and YAML skill metadata parsed; naming, listing lengths, asset references and local skill references checked.
- Bundled Python scripts parsed and their help commands executed.
- Exercised valid course packaging, inventory and checksum verification, overwrite refusal, output-inside-source refusal, broken/escaping link and fence rejection, and credential-filename rejection.
- Final ZIP paths, inventory and CRC integrity checked. No live account import, installation, hosted UI, publishing or model-behavior evaluation performed.
