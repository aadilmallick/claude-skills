---
name: produce-project-content
description: "Use to turn a software project, lesson, demo or technical result into original YouTube, LinkedIn, short video, article or newsletter drafts."
---

# Produce project content
Turn actual work into clear teaching and useful marketing. Read `references/editorial-rules.md`. Use `templates/content-brief.md`, `templates/production-pack.md`, and `templates/voice-guide.md` as needed.

1. Inspect the selected project, lesson, screenshots, or notes. Identify what is built and demonstrable versus planned. Retain paths, sections, timestamps, and test limitations in an evidence ledger. Do not claim access to an absent project or private creator page.
2. Establish one audience, one problem, one takeaway, and one relevant call to action. Reuse an existing voice guide and offer description. If missing, infer a provisional guide from user-authored samples; otherwise use plain, direct teaching without fabricated personal stories.
3. Find the strongest concrete angle: problem solved, useful result, surprising constraint, or an instructive failure. Offer up to three hooks, with a brief reason and evidence for each. Avoid guarantees, made-up metrics, and algorithm folklore.
4. Match the requested scope. For an unspecified content pack, draft one 3-5 minute demo-video script, two distinct LinkedIn posts, one 30-45 second short, and one CTA. Do not create every format if the user requests only one.
5. For video, use a two-column script: narration and visuals, with approximate duration. Show the result early, demonstrate reproducible steps, explain the mechanism, and finish with a useful next action. Include recording checklist, exact screens/files to capture, readable code framing, B-roll only where useful, and caption suggestions.
6. Adapt each channel to a distinct reader need. A short should work on its own; a LinkedIn post should add an observation or lesson rather than copy the transcript. Use original wording; learn structural techniques from reference creators without impersonating them or copying scripts.
7. Check existing content records for repeated topics and hooks. Save drafts and source mappings in the current workspace, never in the plugin installation. Use `scripts/content_queue.py` to maintain the ledger if execution is available. Keep original drafts when revising.
8. Run the editorial review skill before marking a draft reviewed. Deliver copy-ready drafts, the source/evidence notes separately, and the highest-value next production step. Mark missing footage or unverified claims precisely.

## Owner context, provisional
Prior interests include software/AI/ML teaching, useful browser/web tools, technical demos, and a math whiteboard. A previous YouTube plan used 8-10 hours weekly, screen recordings, and occasional face-to-camera. Treat that as a starting preference to confirm if it materially affects a new plan. Notes, tutoring, consulting, and a community are possible offers, not established inventory or revenue.

## Capabilities
This package writes drafts and manages local records. It cannot render/edit video, read all chats, upload posts, retrieve private analytics, or run recurring tasks by itself. Discover available connections when the user requests those actions; don't pretend they are bundled.
