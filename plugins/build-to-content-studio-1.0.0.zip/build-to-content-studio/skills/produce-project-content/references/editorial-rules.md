# Editorial contract
Prefer a concrete result, a visible demonstration, a concise explanation, and one useful next step. A hook must accurately represent the result. State uncertain claims as uncertain. Verify current platform rules, tool features or prices using official sources when those details matter; the package contains no frozen algorithm or platform-limit advice.

## Evidence ledger
| Draft claim | Source path/URL and section | Observed result | Limits | Keep/revise/remove |
|---|---|---|---|---|

## Local queue
Standard-library Python 3.10+; run commands from this skill directory or resolve the script's absolute path. Replace example paths. Store state outside the plugin installation. One writer at a time.
```text
python scripts/content_queue.py --queue /user/content/queue.json add --title "What the demo taught me" --source /user/project/README.md --audience "JavaScript developers" --channel linkedin --draft /user/content/post-01.md --cta "Try the demo"
python scripts/content_queue.py --queue /user/content/queue.json list
python scripts/content_queue.py --queue /user/content/queue.json update 1 --status reviewed --note "Feature claims checked against demo; performance claim removed"
python scripts/content_queue.py --queue /user/content/queue.json export /user/content/calendar-v1.md
```
Channels: youtube, linkedin, short, newsletter, article. States: idea, draft, reviewed, published. Publication is a manually recorded event, requires an actual URL, and makes no network request. Metrics and richer claim notes belong in the production pack; the ledger does not fetch analytics or validate source contents. Never fabricate a published URL to advance a state.
