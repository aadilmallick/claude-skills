# Content brief
Project/source and inspected version: <value>
Audience and problem: <value>
One takeaway: <value>
Demonstrable result: <value>
Evidence and limitations: <value>
Channel, target duration and time budget: <value>
Hook candidates and chosen angle: <value>
CTA and actual destination: <value>
Existing related content and new contribution: <value>
