# Production pack
Draft ID, source version, date: <value>
Audience, promise, CTA: <value>

## Video script
| Estimated time | Narration | Visual/recording action | Evidence |
|---|---|---|---|

## Supporting drafts
<Only requested formats; each has a distinct angle and complete copy.>

## Capture checklist
<Exact screens, starting data, recording order, legibility and captions.>

## Claim review
<Claim-to-source mapping; implemented/tested/planned distinctions; unresolved gaps.>

## Outcome log
Publication URL and reported/verified status: <value>
Observation window: <value>
Metric, numerator, denominator, source: <value>
Next experiment and success criterion: <value>
