# Voice guide
Status: provisional until grounded in user-authored samples.
Samples and what they establish: <value>
Audience: <value>
Tone: plain, concrete, curious; adjust from samples.
Preferred vocabulary and sentence length: <value>
Personal claims permitted by evidence: <value>
Phrases to avoid: <value>
Example before/after in the user's own voice: <value>
