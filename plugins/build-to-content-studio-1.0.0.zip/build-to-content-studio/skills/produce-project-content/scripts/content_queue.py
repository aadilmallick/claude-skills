"""Maintain an explicit content draft ledger. No publishing or network access."""
import argparse, datetime, json, os, pathlib, tempfile

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--queue', type=pathlib.Path, required=True)
    sub = p.add_subparsers(dest='cmd', required=True)
    add = sub.add_parser('add'); add.add_argument('--title', required=True)
    add.add_argument('--source', required=True); add.add_argument('--audience', required=True)
    add.add_argument('--channel', choices=['youtube', 'linkedin', 'short', 'newsletter', 'article'], required=True)
    add.add_argument('--cta', default=''); add.add_argument('--draft', default='')
    update = sub.add_parser('update'); update.add_argument('id', type=int)
    update.add_argument('--status', choices=['idea', 'draft', 'reviewed', 'published'], required=True)
    update.add_argument('--note', required=True); update.add_argument('--url')
    sub.add_parser('list')
    export = sub.add_parser('export'); export.add_argument('output', type=pathlib.Path)
    a = p.parse_args()
    data = json.loads(a.queue.read_text(encoding='utf-8-sig')) if a.queue.exists() else {'schema_version': 1, 'items': []}
    if a.cmd == 'add':
        if not all(v.strip() for v in [a.title, a.source, a.audience]): p.error('Title, source and audience cannot be blank')
        item = {'id': max([i['id'] for i in data['items']], default=0)+1, 'title': a.title,
                'source': a.source, 'audience': a.audience, 'channel': a.channel, 'cta': a.cta,
                'draft': a.draft, 'status': 'draft' if a.draft else 'idea', 'history': []}
        data['items'].append(item)
    elif a.cmd == 'update':
        item = next((i for i in data['items'] if i['id'] == a.id), None)
        if item is None: p.error('Unknown item ID')
        if not a.note.strip(): p.error('A review or outcome note is required')
        if a.status == 'published' and not (a.url or item.get('url')): p.error('Published state requires the actual post URL')
        item['status'] = a.status
        if a.url: item['url'] = a.url
        item['history'].append({'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': a.status, 'note': a.note})
    elif a.cmd == 'export':
        if a.output.resolve() == a.queue.resolve(): p.error('Export must not overwrite the queue')
        if a.output.exists(): p.error('Export file already exists; choose a new filename')
        a.output.parent.mkdir(parents=True, exist_ok=True)
        def cell(value): return str(value).replace('|', '\\|').replace('\n', ' ')
        rows = ['# Content queue', '', '| ID | Title | Channel | Status | Source |', '|---|---|---|---|---|']
        rows += ['| ' + ' | '.join(cell(i[k]) for k in ['id','title','channel','status','source']) + ' |' for i in data['items']]
        a.output.write_text('\n'.join(rows)+'\n', encoding='utf-8'); print(str(a.output)); return
    else:
        print(json.dumps(data, indent=2, ensure_ascii=False)); return
    a.queue.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(dir=a.queue.parent, suffix='.tmp')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream: json.dump(data, stream, indent=2, ensure_ascii=False)
        os.replace(temp, a.queue)
    finally:
        if os.path.exists(temp): os.unlink(temp)
    print(json.dumps(item, indent=2))

if __name__ == '__main__': main()
