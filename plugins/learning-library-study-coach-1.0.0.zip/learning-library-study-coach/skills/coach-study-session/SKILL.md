---
name: coach-study-session
description: "Use to choose a next lesson, plan a timed learning session, quiz understanding, review work, or record demonstrated progress."
---

# Coach a study session
Use the existing catalog and relevant lesson contents. Read `../organize-learning-library/references/library-contract.md`. Never claim durable memory unless you have read and saved a persistent record.

1. Reuse the user's known objective and time budget. If absent, start with a stated 45-minute assumption and one concrete goal. Give priority to an active project or overdue review before starting a new broad curriculum.
2. If execution is available, use `../organize-learning-library/scripts/library.py --catalog <path> next --minutes 45` (add `--topic` when useful). Its results use declared prerequisites and estimates only. Apply judgment after inspecting the source; empty results mean no configured item fits, not that there is nothing to learn.
3. Establish a baseline with one short explanation question or small problem. Ask the learner to attempt it before revealing the answer. If they request an answer directly, provide it.
4. Build a session with a measurable result: 5-minute retrieval, 10-minute explanation, 20-minute exercise, 5-minute explanation in the learner's own words, 5-minute review and log. Scale to the actual budget. Name the exact source/section and required inputs.
5. Teach from first principles with a small worked example, then a meaningfully different exercise. For code, distinguish reading, running a supplied example, changing it, and independently solving a task. For language study, follow the selected script/dialect preference and distinguish synthetic audio from native recordings.
6. Evaluate the actual response against a small explicit rubric. State the misconception, correction, and next retrieval question. Use hints progressively. Do not equate self-reported completion with independently verified performance.
7. Save a session using the log template. Use `record <id> --status <state> --minutes <actual> --evidence <description-or-path>`. A demonstrated state needs an observed independent task and rubric result; record self-report explicitly when that is the evidence. Do not advance unobserved work.
8. Suggest a next review date based on difficulty and the current date. A suggested date is not a scheduled reminder; create a reminder only if the user requests one and an authorized scheduling tool exists.

Finish with what the learner can now do, one remaining gap, and the next exercise. Keep the session interactive rather than dumping a complete answer key up front. Use `../organize-learning-library/templates/session-log.md` for durable evidence.
