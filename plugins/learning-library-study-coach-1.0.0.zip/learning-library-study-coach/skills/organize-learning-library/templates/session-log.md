# Study session
Date and actual minutes: <value>
Catalog item ID and exact section: <value>
Objective: <observable ability>
Baseline question and response: <value>
Work attempted: <value>
Evidence path or actual response: <value>
Assistance used: <none/hints/worked example>
Rubric and result: <criteria, observations, gaps>
Evidence type: <observed execution / reviewed response / learner self-report>
Status recorded: <created/studying/practiced/demonstrated>
Next retrieval question and suggested date: <value; not a reminder>
