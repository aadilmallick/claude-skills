# Learning library notes
Updated: <date>
Goal and weekly budget: <confirmed or assumed>

| Item ID | Source section | Coverage | Estimated effort and basis | Prerequisites and confidence | Canonical/duplicate notes |
|---|---|---|---|---|---|

## Overlap decisions
<Sources compared, reusable coverage, distinct exercises worth keeping.>

## Source changes and access gaps
<Unavailable files, modified hashes, stale links, uninspected packages.>

## Next project
<One output, definition of done, first activity.>
