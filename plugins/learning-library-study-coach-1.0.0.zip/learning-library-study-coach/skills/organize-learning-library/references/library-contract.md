# Library contract and commands
The catalog is UTF-8 JSON: `schema_version`, `items`, `sessions`. Each item has a stable path-derived `id`, title, source path, content hash, topic, status, estimated minutes, prerequisite item IDs in `requires`, and evidence entries. IDs change if a path changes. ZIP members are not separate indexed lessons.

Status meanings:
- created: source exists; no study implied.
- studying: an active learning attempt.
- practiced: a completed relevant exercise, with evidence.
- demonstrated: an independent task meets stated criteria, with evidence.

```text
python scripts/library.py --catalog /user/work/learning-library/catalog.json import /user/courses --topic ai
python scripts/library.py --catalog /user/work/learning-library/catalog.json list
python scripts/library.py --catalog /user/work/learning-library/catalog.json configure ITEM_ID --minutes 30 --topic ai
python scripts/library.py --catalog /user/work/learning-library/catalog.json configure ITEM_ID --requires PREREQUISITE_ID
python scripts/library.py --catalog /user/work/learning-library/catalog.json next --minutes 45 --topic ai
python scripts/library.py --catalog /user/work/learning-library/catalog.json record ITEM_ID --status practiced --minutes 30 --evidence "Solved exercise 2; review at notes/session-01.md"
```
Run from this skill directory or use absolute script paths. Replace example paths and IDs with real values. `configure ITEM_ID --requires` clears prerequisites. Selection prefers already-started items; prerequisite eligibility requires demonstrated status. Atomic writes reduce partial-file risk but do not support concurrent writers. JSON files are portable; back them up before bulk editing. No cloud storage or network calls are included.

Suggested initial topic families based on the owner's requests, not verified catalog entries: math for CS/ML; databases; ML/LLMs; agents/AI tools; React Native/Electron/web graphics; AWS/Terraform/PowerShell; marketing/consulting; French and Roman-script Hyderabadi Urdu. Do not mark these as owned or studied without sources.
