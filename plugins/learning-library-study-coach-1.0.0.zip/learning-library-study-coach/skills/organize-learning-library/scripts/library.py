"""Portable learning catalog. Standard-library Python 3.10+."""
import argparse, datetime, hashlib, json, os, pathlib, tempfile, zipfile

STATES = ['created', 'studying', 'practiced', 'demonstrated']
SKIP = {'.git', '.venv', 'node_modules', 'dist', 'build', '__pycache__'}

def read(path):
    if not path.exists():
        return {'schema_version': 1, 'items': [], 'sessions': []}
    return json.loads(path.read_text(encoding='utf-8-sig'))

def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(dir=path.parent, suffix='.tmp')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(data, stream, indent=2, ensure_ascii=False)
            stream.write('\n')
        os.replace(temp, path)
    finally:
        if os.path.exists(temp): os.unlink(temp)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--catalog', type=pathlib.Path, required=True)
    subs = parser.add_subparsers(dest='command', required=True)
    imp = subs.add_parser('import')
    imp.add_argument('source', type=pathlib.Path)
    imp.add_argument('--topic', default='unclassified')
    edit = subs.add_parser('configure')
    edit.add_argument('id'); edit.add_argument('--minutes', type=int)
    edit.add_argument('--topic'); edit.add_argument('--requires', nargs='*')
    rec = subs.add_parser('record')
    rec.add_argument('id'); rec.add_argument('--status', choices=STATES, required=True)
    rec.add_argument('--minutes', type=int, required=True)
    rec.add_argument('--evidence', required=True)
    subs.add_parser('list')
    nxt = subs.add_parser('next'); nxt.add_argument('--minutes', type=int, default=45)
    nxt.add_argument('--topic')
    args = parser.parse_args(); data = read(args.catalog)
    if args.command == 'import':
        src = args.source.resolve(strict=True)
        files = sorted(src.rglob('*')) if src.is_dir() else [src]
        known = {i['source'] for i in data['items']}; added = 0
        for file in files:
            if not file.is_file() or file.is_symlink(): continue
            if any(p in SKIP for p in file.relative_to(src if src.is_dir() else src.parent).parts): continue
            if file.suffix.lower() not in {'.md', '.mdx', '.pdf', '.html', '.zip'}: continue
            location = str(file)
            if location in known: continue
            digest = hashlib.sha256()
            with file.open('rb') as stream:
                for block in iter(lambda: stream.read(1024*1024), b''): digest.update(block)
            item = {'id': hashlib.sha256(location.encode()).hexdigest()[:16], 'title': file.stem,
                    'source': location, 'sha256': digest.hexdigest(), 'topic': args.topic,
                    'status': 'created', 'minutes': 45, 'requires': [], 'evidence': []}
            if file.suffix.lower() == '.zip':
                try:
                    with zipfile.ZipFile(file) as archive:
                        item['archive_members'] = len(archive.infolist())
                        item['contents_reviewed'] = False
                except zipfile.BadZipFile:
                    item['warning'] = 'Invalid ZIP; contents not inspected'
            data['items'].append(item); known.add(location); added += 1
        save(args.catalog, data); print(json.dumps({'added': added, 'total': len(data['items'])}))
    elif args.command in {'configure', 'record'}:
        item = next((i for i in data['items'] if i['id'] == args.id), None)
        if item is None: parser.error('Unknown item ID')
        if args.command == 'configure':
            if args.minutes is not None:
                if args.minutes <= 0: parser.error('Minutes must be positive')
                item['minutes'] = args.minutes
            if args.topic: item['topic'] = args.topic
            if args.requires is not None:
                by_id = {i['id']: i for i in data['items']}
                if any(i not in by_id or i == args.id for i in args.requires): parser.error('Unknown or self prerequisite')
                def reaches(start, target, seen):
                    if start == target: return True
                    if start in seen: return False
                    seen.add(start)
                    return any(reaches(i, target, seen) for i in by_id[start].get('requires', []))
                if any(reaches(i, args.id, set()) for i in args.requires): parser.error('Prerequisite cycle')
                item['requires'] = args.requires
        else:
            if args.minutes < 0 or not args.evidence.strip(): parser.error('Nonnegative minutes and evidence are required')
            session = {'item_id': args.id, 'status': args.status, 'minutes': args.minutes,
                       'evidence': args.evidence, 'at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
            item['status'] = args.status; item['evidence'].append(session); data['sessions'].append(session)
        save(args.catalog, data); print(json.dumps(item, indent=2))
    else:
        items = data['items']
        if args.command == 'next':
            if args.minutes <= 0: parser.error('Minutes must be positive')
            completed = {i['id'] for i in items if i['status'] == 'demonstrated'}
            items = [i for i in items if i['status'] != 'demonstrated' and i['minutes'] <= args.minutes
                     and set(i.get('requires', [])).issubset(completed)
                     and (not args.topic or i['topic'] == args.topic)]
            items = sorted(items, key=lambda i: (-STATES.index(i['status']), i['title']))[:3]
        print(json.dumps(items, indent=2, ensure_ascii=False))

if __name__ == '__main__': main()
